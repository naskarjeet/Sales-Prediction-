"""
Sales Forecasting
------------------
Goal: Predict future sales based on historical (time-series) retail data.

Steps covered:
1. Build a realistic daily retail sales dataset (trend + seasonality + promotions)
2. Visualize the raw series and its seasonal pattern
3. Feature-engineer time components (trend, day-of-week, month, promo flag)
4. Train a regression-based forecasting model (captures trend + seasonal + promo effects)
5. Compare forecast vs actual sales on a held-out future period
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, r2_score

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
OUT = "outputs"

# ---------------------------------------------------------------
# 1. BUILD DATASET — 3 years of daily retail sales
# ---------------------------------------------------------------
dates = pd.date_range("2023-01-01", "2025-12-31", freq="D")
n = len(dates)

t = np.arange(n)
trend = 500 + 0.35 * t                                   # slow upward trend
weekly_season = 80 * np.sin(2 * np.pi * dates.dayofweek.values / 7)
yearly_season = 250 * np.sin(2 * np.pi * dates.dayofyear.values / 365.25 - 1.2)
# promo days: random flash sales + fixed Nov/Dec holiday boost
promo_flag = ((np.random.rand(n) < 0.05) | ((dates.month == 11) & (dates.day >= 20)) |
              (dates.month == 12)).astype(int)
promo_boost = promo_flag * np.random.uniform(150, 400, n)
noise = np.random.normal(0, 60, n)

sales = (trend + weekly_season + yearly_season + promo_boost + noise).clip(min=50)

df = pd.DataFrame({"date": dates, "sales": sales.round(2), "promo": promo_flag})
df.to_csv(f"{OUT}/retail_sales_data.csv", index=False)
print(f"Dataset created: {df.shape[0]} daily records "
      f"({df.date.min().date()} to {df.date.max().date()})")

# ---------------------------------------------------------------
# 2. RAW SERIES + SEASONAL VIEW
# ---------------------------------------------------------------
fig, axes = plt.subplots(2, 1, figsize=(12, 8))
axes[0].plot(df.date, df.sales, linewidth=0.8, color="#4C72B0")
axes[0].set_title("Daily Retail Sales (2023–2025)")
axes[0].set_ylabel("Sales")

monthly = df.set_index("date")["sales"].resample("MS").mean()
axes[1].plot(monthly.index, monthly.values, marker="o", color="#55A868")
axes[1].set_title("Monthly Average Sales (seasonal pattern)")
axes[1].set_ylabel("Avg Sales")

plt.tight_layout()
plt.savefig(f"{OUT}/sales_overview.png", dpi=130)
plt.close()
print("Saved: sales_overview.png")

# ---------------------------------------------------------------
# 3. FEATURE ENGINEERING (trend + seasonal + promo components)
# ---------------------------------------------------------------
feat = df.copy()
feat["t"] = np.arange(len(feat))
feat["dow"] = feat.date.dt.dayofweek
feat["month"] = feat.date.dt.month
feat["doy_sin"] = np.sin(2 * np.pi * feat.date.dt.dayofyear / 365.25)
feat["doy_cos"] = np.cos(2 * np.pi * feat.date.dt.dayofyear / 365.25)
feat = pd.get_dummies(feat, columns=["dow", "month"], drop_first=True)

# Train on first 2.5 years, test (forecast) on the last 6 months
split_date = "2025-07-01"
train = feat[feat.date < split_date]
test = feat[feat.date >= split_date]

feature_cols = [c for c in feat.columns if c not in ["date", "sales"]]
X_train, y_train = train[feature_cols], train["sales"]
X_test, y_test = test[feature_cols], test["sales"]

# ---------------------------------------------------------------
# 4. MODELS
# ---------------------------------------------------------------
lin_model = LinearRegression()
lin_model.fit(X_train, y_train)
lin_preds = lin_model.predict(X_test)

rf_model = RandomForestRegressor(n_estimators=300, max_depth=8, random_state=RANDOM_STATE)
rf_model.fit(X_train, y_train)
rf_preds = rf_model.predict(X_test)

def report(name, y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    mape = mean_absolute_percentage_error(y_true, y_pred) * 100
    r2 = r2_score(y_true, y_pred)
    print(f"{name}: MAE={mae:.1f} | MAPE={mape:.1f}% | R2={r2:.3f}")
    return {"Model": name, "MAE": round(mae, 1), "MAPE(%)": round(mape, 1), "R2": round(r2, 3)}

print("\nForecast accuracy on last 6 months (held-out):")
res = [report("Linear Regression (trend+season+promo)", y_test, lin_preds),
       report("Random Forest", y_test, rf_preds)]
pd.DataFrame(res).to_csv(f"{OUT}/forecast_accuracy.csv", index=False)

# ---------------------------------------------------------------
# 5. FORECAST VS ACTUAL PLOT
# ---------------------------------------------------------------
plt.figure(figsize=(12, 5))
plt.plot(test.date, y_test, label="Actual Sales", color="black", linewidth=1)
plt.plot(test.date, lin_preds, label="Forecast (Linear model)", color="#4C72B0", linewidth=1)
plt.plot(test.date, rf_preds, label="Forecast (Random Forest)", color="#C44E52",
         linewidth=1, alpha=0.8)
plt.title("Forecast vs Actual Sales (last 6 months)")
plt.ylabel("Sales")
plt.legend()
plt.tight_layout()
plt.savefig(f"{OUT}/forecast_vs_actual.png", dpi=130)
plt.close()
print("Saved: forecast_vs_actual.png")

print("\nAll outputs saved in the 'outputs' folder.")
