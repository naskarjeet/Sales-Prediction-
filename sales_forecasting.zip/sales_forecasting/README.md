# Sales Forecasting

**Goal:** Predict future retail sales based on historical (time-series) data.

## Dataset
Three years (2023–2025) of daily retail sales (`outputs/retail_sales_data.csv`, 1,096 days), built with a realistic mix of:
- **Trend** — slow steady growth over time
- **Weekly seasonality** — sales vary by day of week
- **Yearly seasonality** — sales rise and fall across the year
- **Promotions** — random flash-sale days plus a Nov/Dec holiday sales boost

## Steps Followed
1. **Visualization** — plotted the raw daily series and the monthly average to see trend and seasonal shape (`outputs/sales_overview.png`).
2. **Feature Engineering** — built trend, day-of-week, month, and cyclical (sin/cos of day-of-year) features to capture seasonal + promotional components.
3. **Modeling** — trained two forecasting models on 2.5 years of history and tested on the final 6 months:
   - Linear Regression (trend + seasonal + promo features)
   - Random Forest Regressor
4. **Evaluation** (`outputs/forecast_accuracy.csv`):
   - Linear Regression: MAE ≈ 54.5, MAPE ≈ 6.3%, R² ≈ 0.82 (best)
   - Random Forest: MAE ≈ 73.2, MAPE ≈ 8.9%, R² ≈ 0.68
5. **Forecast vs Actual** — plotted predicted vs actual sales for the held-out 6-month period (`outputs/forecast_vs_actual.png`).

## How to Run
```
pip install pandas numpy scikit-learn matplotlib
python sales_forecast.py
```
All charts and result files are saved into the `outputs/` folder.

## Key Result
The trend + seasonal + promotion feature model (Linear Regression) forecasts daily sales with about **6% average error**, and clearly captures the November–December holiday spike. This kind of model helps a retail business plan inventory and staffing ahead of high-demand periods.

## Tech Stack
Python, pandas, NumPy, scikit-learn, Matplotlib
